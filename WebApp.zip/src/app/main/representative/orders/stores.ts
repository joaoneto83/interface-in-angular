export const storesData = [
    {
        filter: 'representanteGeral',
        stores: [
            'Casas Bahia',
            'Ponto Frio',
            'Elgin Industrial Amazonia LTDA',
            'Elgin SA 02',
            'Magazine Luiza',
            'Lojas Americanas',
            'Pernambucanas'
        ]
    },
    {
        filter: 'varejo',
        stores: [
            'Casas Bahia',
            'Ponto Frio',
            'Elgin Industrial Amazonia LTDA'
        ]
    }
];


